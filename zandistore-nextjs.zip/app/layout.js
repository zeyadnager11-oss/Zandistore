
import './globals.css';

export const metadata = {
  title: 'ZandiStore — متجر زاندي',
  description: 'Bilingual (AR/EN) multi-currency game item store.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="ar" dir="rtl">
      <body>{children}</body>
    </html>
  );
}
